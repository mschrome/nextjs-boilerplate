
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/runtime-node.mjs
var runtime_node_default = async (request) => {
  const url = new URL(request.url);
  return Response.json({
    ok: true,
    runtime: "netlify-functions-node",
    nodeVersion: process.version,
    path: url.pathname,
    now: (/* @__PURE__ */ new Date()).toISOString()
  });
};
export {
  runtime_node_default as default
};
